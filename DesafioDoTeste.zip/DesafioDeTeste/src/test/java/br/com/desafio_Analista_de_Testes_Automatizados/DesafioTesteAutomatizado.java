package br.com.desafio_Analista_de_Testes_Automatizados;



import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runners.JUnit4;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import cucumber.api.java.Before;

public class DesafioTesteAutomatizado {

	static WebDriver driver;
//Desafio 1	
	@FindBy(how = How.XPATH, using ="//*[contains(text(),'Solutions')]")
	 static WebElement LINKMenu_Solutions;	
	@FindBy(how = How.XPATH, using ="//*/a[contains(text(),'Cross Browser Testing')]")
	 static WebElement LINKMenu_Cross_Browser_Testing;
	@FindBy(how = How.XPATH, using ="//*/a[@aria-label=\"dismiss cookie message\"]")
	 static WebElement LINK_OK;
	@FindBy(how = How.XPATH, using ="//*/h3/span[@class='text-neutral-darker']/../../p[2]/a/i")
	 static WebElement LINK_Learn_More;
	@FindBy(how = How.XPATH, using ="//*[@class=\"content-wrapper content-wrapper--neutral-lightest content-wrapper--max-width-1000\"]/div/div/h2")
	 static WebElement LBL_Texto_validacao;
	
	
//devasio 2	
	@FindBy(how = How.XPATH, using ="//*[@name='q']")
	 static WebElement TXT_Pesquisar;
	@FindBy(how =How.XPATH, using="//*/label/div/ul[3]/*")
	static WebElement BTN_Pequisar;
	@FindBy(how =How.XPATH, using="//*/a[@href='/SeleniumHQ/selenium']")
	static WebElement Link_SeleniumHQ_selenium;
	
	@FindBy(how =How.XPATH, using="//*[@class='files js-navigation-container js-active-navigation-container']/tbody")
	static WebElement Tabela_ultimo_commit;

//devasio 3
		@FindBy(how = How.XPATH, using ="//*[contains(text(),'Java docs')]")
		 static WebElement Link_Java_docs;
		@FindBy(how = How.XPATH, using ="//table//tbody")
		 static WebElement Tabela_Pro_vs;
		
//-------------------------------------------------	
		
		@Rule
		  public TestName name= new TestName();
	      static String nameDoMetodo;	
	      
	/**
	 * Desafio_1_Verificar_se_contem_texto_Run_Selenium_tests_securely_in_the_cloud_no_saucelabs
	 *   Desafio 1
			Passo-a-passo:
			1. Acessar o site saucelabs.com
			2. Acessar o menu Solutions > Web Testing > Cross Browser Testing
			3. Em "AUTOMATE YOUR SELENIUM TESTS" clicar no link "Learn More"
			4. Verificar se contem texto "Run Selenium tests securely in the cloud"    
	 * @throws InterruptedException 
	 */
	      
	@Test
	public void Desafio_1_Verificar_se_contem_texto_Run_Selenium_tests_securely_in_the_cloud_no_saucelabs() throws InterruptedException {	

			System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\driver\\chromedriver.exe"); 
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--start-maximized");
			driver = new ChromeDriver( options );

			//1. Acessar o site saucelabs.com
				driver.get("http://saucelabs.com/");
				driver.manage().timeouts().implicitlyWait(18, TimeUnit.SECONDS);
				PageFactory.initElements(driver, DesafioTesteAutomatizado.class);

			//  2. Acessar o menu Solutions > Web Testing > Cross Browser Testing
				LINKMenu_Solutions.click();
				Thread.sleep(2000);
				LINKMenu_Cross_Browser_Testing.click();
				Thread.sleep(2000);
			//	3. Em "AUTOMATE YOUR SELENIUM TESTS" clicar no link "Learn More"
				LINK_OK.click();
				UtilClass util=new UtilClass();
				util.scrollvertical("500");
				LINK_Learn_More.click();
				Thread.sleep(2000);

			//	4. Verificar se contem texto "Run Selenium tests securely in the cloud"
				Thread.sleep(2000);
				//util.scrollvertical("500");
				util.executarJavaScript("window.scrollBy(0, arguments[0])", (LBL_Texto_validacao.getLocation().y)-200);
				String verificarTexo=LBL_Texto_validacao.getText();
				nameDoMetodo=name.getMethodName();
				util.highlightElement(LBL_Texto_validacao);
				util.Screenshot();
				Assert.assertEquals("Run Selenium tests securely in the cloud",LBL_Texto_validacao.getText());	
	}

	  /**
	   * 
	   * Desafio_2_Verificar_qual_arquivo_ou_pasta_com_o_commit_mais_antigo_no_github
    	 	Desafio 2
			Passo-a-passo:
				1. Acessar o site https://github.com
				2. Pesquisar por selenium
				3. Acessar SeleniumHQ/selenium
				4. Verificar qual arquivo ou pasta com o commit mais antigo.
	 * @throws InterruptedException 
	   */
	 
      @Test
	  public void Desafio_2_Verificar_qual_arquivo_ou_pasta_com_o_commit_mais_antigo_no_github() throws InterruptedException {	
    	  
    	 
    		  System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\driver\\chromedriver.exe"); 
    		  ChromeOptions options = new ChromeOptions();
    		  options.addArguments("--start-maximized"); 
    		  driver = new ChromeDriver( options );

    		  //Passo 1:  Acessar o site https://github.com
	    		  driver.get("https://github.com/");
	    		  driver.manage().timeouts().implicitlyWait(18, TimeUnit.SECONDS);
	    		  PageFactory.initElements(driver, DesafioTesteAutomatizado.class);
    		  // Passo 2. Pesquisar por selenium
	    		  TXT_Pesquisar.sendKeys("selenium");
	    		  Thread.sleep(2000);
	    		  BTN_Pequisar.click();
    		  // Passo  3. Acessar SeleniumHQ/selenium
	    		  Link_SeleniumHQ_selenium.click();

    		  // Passo  4. Verificar qual arquivo ou pasta com o commit mais antigo
	    		  UtilClass util =new UtilClass();  	
	    		 WebElement ElementTabela=util.buscarNaTabelaUtimoCommit(Tabela_ultimo_commit);
	    		 nameDoMetodo=name.getMethodName();
	    		 util.highlightElement(ElementTabela);
	    		 util.Screenshot();    		 
	    		 assertTrue(ElementTabela.isEnabled());
    	  
	  }

      /**
       Desafio 3
			Passo-a-passo:
			1. Acessar o site http://extentreports.com
			2. Acessar o menu Documentation > Version 3 e clicar em Java ou .Net
			3. Na tabela "Pro vs Community Version" validar se a opção "Offline report" está disponível na versão Pro
       * @throws IOException
       * @throws InterruptedException
       */
      
      @Test
	  public void Desafio_3_validar_se_a_opção_Offline_report_no_extentreports() throws IOException, InterruptedException {	
    	 

    		  System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\driver\\chromedriver.exe"); 
    		  ChromeOptions options = new ChromeOptions();
    		  options.addArguments("--start-maximized");
    		  driver = new ChromeDriver( options );

    		 // 1. Acessar o site http://extentreports.com
	    		  driver.get("http://extentreports.com");
	    		  driver.manage().timeouts().implicitlyWait(18, TimeUnit.SECONDS);
	    		  PageFactory.initElements(driver, DesafioTesteAutomatizado.class);    		 
    		 //2. Acessar o menu Documentation > Version 3 e clicar em Java
	    		  Thread.sleep(2000);
	              Link_Java_docs.click();       		 		  
    		 // 3. Na tabela "Pro vs Community Version" validar se a opção "Offline report" está disponível na versão Pro
	    		  UtilClass util =new UtilClass();
	    		  nameDoMetodo=name.getMethodName();    		  
	    		  Assert.assertEquals("V",util.buscarNaTabela(Tabela_Pro_vs,"Offline report", 3));
	    		  util.Screenshot();
	  }

  
	 
      @After	 
	  public void afterMethod() {
		 driver.quit();	 
	  }	
      
  
}
