package br.com.desafio_Analista_de_Testes_Automatizados;

 
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.rules.TestName;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

 
public class UtilClass { 
	static WebDriver driver;
	
	
	public UtilClass(){
		DesafioTesteAutomatizado desafio=new DesafioTesteAutomatizado();
		this.driver = desafio.driver;
	}

	public  void highlightElement( WebElement element){
  		try {
  			if (driver instanceof JavascriptExecutor) {
  				JavascriptExecutor js = (JavascriptExecutor) driver;
  				js.executeScript("arguments[0].style.border='3px solid red'", element);
  			}	
  		} catch (Exception e) {
  			e.getMessage();
  		}
	}
	
	public  void acessar_site(String url){
  		try {
  			System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\driver\\chromedriver.exe"); //chromedriver  selecionar o driver gslima
			driver = new ChromeDriver();				
			driver.get(url);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
  		} catch (Exception e) {
  			e.getMessage();
  		}
	}

	public static  void scrollvertical( String coordenada) throws InterruptedException{
		
		Thread.sleep(2000);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(document.body.scrollHeight,"+coordenada+")");	
		
	}
	public static  void scroll( WebElement Element) throws InterruptedException{
		 Thread.sleep(1000);
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(True);",Element);			
		
	}
	
	
	public void Screenshot() {
		try {
			UtilClass u= new UtilClass();
		    DesafioTesteAutomatizado desafio =new DesafioTesteAutomatizado();
			TakesScreenshot ss = (TakesScreenshot) driver;
			File arquivo = ss.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(arquivo, new File(System.getProperty("user.dir") +"\\target\\"+"screenshot\\ " + desafio.nameDoMetodo + ".jpg"));
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}

	}

	
	/************** JavaScript *********************/
	public Object executarJavaScript(String cmd, Object... param) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		return js.executeScript(cmd, param);
	}
	

	
/************** Tabela Pro vs Community Version*********************/
	public String  buscarNaTabela( WebElement Element, String nomeDacoluna, int valorOndeBuscaOvalor){
				   String valorRestorno = null;
				   UtilClass util =new UtilClass();
					//procurar coluna do registro
					WebElement tabela =Element;
				
					List<WebElement> colunas = tabela.findElements(By.xpath(".//tr"));
					int idColuna = -1;
					for(int i = 0; i < colunas.size(); i++) {
							if(colunas.get(i).getText().equals(nomeDacoluna)) {
								idColuna = i+1;
								break;
							}
					}

					if(tabela.findElement(By.xpath("//table//tbody//tr["+idColuna+"]/td["+valorOndeBuscaOvalor+"]/*[@class='fa fa-check text-success']")).isEnabled()) {
						util.executarJavaScript("window.scrollBy(0, arguments[0])",(tabela.findElement(By.xpath("//table//tbody//tr["+idColuna+"]/td["+valorOndeBuscaOvalor+"]/*[@class='fa fa-check text-success']")).getLocation().y)-200);
						util.highlightElement(tabela.findElement(By.xpath("//table//tbody//tr["+idColuna+"]/td["+valorOndeBuscaOvalor+"]/*[@class='fa fa-check text-success']")));
						valorRestorno="V";						
					}else if(tabela.findElement(By.xpath("//table//tbody//tr["+idColuna+"]/td["+valorOndeBuscaOvalor+"]/*[@class='fa fa-close text-danger']")).isEnabled()) {
						util.executarJavaScript("window.scrollBy(0, arguments[0])",(tabela.findElement(By.xpath("//table//tbody//tr["+idColuna+"]/td["+valorOndeBuscaOvalor+"]/*[@class='fa fa-close text-danger']")).getLocation().y)-200);
						util.highlightElement(tabela.findElement(By.xpath("//table//tbody//tr["+idColuna+"]/td["+valorOndeBuscaOvalor+"]/*[@class='fa fa-close text-danger']")));
						valorRestorno="X";
					}else {
						valorRestorno="";
					}	

				return valorRestorno;
				
	    }
			
/************** Tabela Pro vs Community Version 
 * * @throws InterruptedException 
 * *********************/
	public WebElement  buscarNaTabelaUtimoCommit( WebElement Element) throws InterruptedException{
				   String valorRestorno = null;
				   UtilClass utils =new UtilClass();
					//procurar coluna do registro
					WebElement tabela =Element;
				
					List<WebElement> colunas = tabela.findElements(By.xpath("./tr[@class='js-navigation-item']"));
					int idColuna = -1;
					String commit_mais_antigo=null;
					int quantidade_dias; 
					int quantidade_dias_meses = 0;
					int quantidade_dias_years = 0;
					for(int i = 1; i < colunas.size(); i++) {
						   WebElement linhas = tabela.findElement(By.xpath("./tr[@class='js-navigation-item']["+i+"]/td[4]"));
						 
							String periodoCommit;
							periodoCommit=linhas.getText();

							if (periodoCommit.contains("day")) {
								if ((periodoCommit.substring(0, periodoCommit.indexOf("d")).trim()).equals("a")) {
									quantidade_dias=1;
								}else {
									quantidade_dias=Integer.valueOf(periodoCommit.substring(0, periodoCommit.indexOf("d")).trim() );
									//System.out.println("  Dias: "+quantidade_dias);
								}
							}else if(periodoCommit.contains("years")) {
                               if ((periodoCommit.substring(0, periodoCommit.indexOf("y")).trim()).equals("a")) {
								quantidade_dias_years=360;
								//System.out.println("years em Dias: "+quantidade_dias_years);
                               }else {
                            	   quantidade_dias_years=(Integer.parseInt(periodoCommit.substring(0, periodoCommit.indexOf("y")).trim()  ))*365;
   								//System.out.println("years em Dias: "+quantidade_dias_years);
                               }
								
							}else if(periodoCommit.contains("month")) {
								
								if((periodoCommit.substring(0, periodoCommit.indexOf("month")).trim()).equals("a")) {
									quantidade_dias_years=30;
								//	System.out.println("month: "+quantidade_dias_years);
								}else {
									quantidade_dias_years=(Integer.valueOf(periodoCommit.substring(0, periodoCommit.indexOf("month")).trim()   ))*30;
									//System.out.println("month: "+quantidade_dias_years);
								}
							}
						  							
							if(quantidade_dias_meses>=quantidade_dias_years) {
								commit_mais_antigo =periodoCommit;
							}else if(quantidade_dias_years>=quantidade_dias_meses) {
								commit_mais_antigo =periodoCommit;
							}
					}

					Thread.sleep(2000);
					utils.executarJavaScript("window.scrollBy(0, arguments[0])", (utils.driver.findElement(By.xpath("//*[contains(text(),'"+commit_mais_antigo+"')]")).getLocation().y)-200);

				return utils.driver.findElement(By.xpath("//*[contains(text(),'"+commit_mais_antigo+"')]"));	
	    }
	
	
	
}