package junitcucumber;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;

import cucumber.api.PendingException;
import cucumber.api.java.pt.Dado;
import cucumber.api.java.pt.Então;
import cucumber.api.java.pt.Quando;


public class UserSteps {

	@Dado("^que acessei corretamente o site: saucelabs\\.com$")
	public void queAcesseiCorretamenteOSiteSaucelabsCom() throws Throwable {
	   
	}

	@Dado("^acessei o menu: Solutions > Web Testing > Cross Browser Testing$")
	public void acesseiOMenuSolutionsWebTestingCrossBrowserTesting() throws Throwable {
	  
	}

	@Dado("^Clique no botão clicar no link:  Learn More$")
	public void cliqueNoBotãoClicarNoLinkLearnMore() throws Throwable {
	  
	}

	@Então("^a devera aparecer a mensagem: Run Selenium tests securely in the cloud$")
	public void aDeveraAparecerAMensagemRunSeleniumTestsSecurelyInTheCloud() throws Throwable {
	  
	}


	@Quando("^Executa-lo aperação$")
	public void executaLoAperação() throws Throwable {
		   
	}
}
